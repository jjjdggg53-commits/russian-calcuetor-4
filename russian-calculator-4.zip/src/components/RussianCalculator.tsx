/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Flame } from 'lucide-react';
import { AccessMode } from '../types';

interface RussianCalculatorProps {
  onUnlock: (mode: AccessMode) => void;
}

export default function RussianCalculator({ onUnlock }: RussianCalculatorProps) {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [flashScreen, setFlashScreen] = useState(false);

  // Key press listener for the physical keyboard calculator usage!
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key;
      if (/[0-9]/.test(key)) {
        handleNumber(key);
      } else if (['+', '-', '*', '/'].includes(key)) {
        handleOperator(key === '*' ? '×' : key === '/' ? '÷' : key);
      } else if (key === 'Enter' || key === '=') {
        handleCalculate();
      } else if (key === 'Backspace') {
        handleBackspace();
      } else if (key === 'Escape' || key === 'c' || key === 'C') {
        handleClear();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [display, equation]);

  const handleNumber = (num: string) => {
    setDisplay((prev) => {
      if (prev === '0' || prev === 'ОШИБКА' || prev === 'ДОСТУП') {
        return num;
      }
      return prev + num;
    });
  };

  const handleOperator = (op: string) => {
    setEquation(display + ' ' + op + ' ');
    setDisplay('0');
  };

  const handleBackspace = () => {
    setDisplay((prev) => {
      if (prev.length <= 1 || prev === 'ОШИБКА' || prev === 'ДОСТУП') {
        return '0';
      }
      return prev.slice(0, -1);
    });
  };

  const handleClear = () => {
    setDisplay('0');
    setEquation('');
  };

  const checkSecretCode = (code: string): boolean => {
    if (code === '1987') {
      setFlashScreen(true);
      setDisplay('ИГРОК-87'); // "PLAYER-87" in Russian-like look
      setTimeout(() => {
        onUnlock('player');
      }, 1000);
      return true;
    } else if (code === '20186356') {
      setFlashScreen(true);
      setDisplay('ГЛАВНЫЙ'); // "MAIN/ROOT" in Russian
      setTimeout(() => {
        onUnlock('admin');
      }, 1000);
      return true;
    }
    return false;
  };

  const handleCalculate = () => {
    // Check code in current display before evaluating math
    const trimmed = display.trim();
    if (checkSecretCode(trimmed)) return;

    if (!equation) return;

    try {
      const parts = equation.split(' ');
      const num1 = parseFloat(parts[0]);
      const op = parts[1];
      const num2 = parseFloat(display);

      let result = 0;
      if (op === '+') result = num1 + num2;
      else if (op === '-') result = num1 - num2;
      else if (op === '×') result = num1 * num2;
      else if (op === '÷') {
        if (num2 === 0) throw new Error('div 0');
        result = num1 / num2;
      }

      // Check if resulting calculation matches a code!
      const resultStr = String(Math.round(result));
      if (checkSecretCode(resultStr)) return;

      // format result
      let formattedResult = String(Number(result.toFixed(6)));
      if (formattedResult.length > 10) {
        formattedResult = result.toExponential(4);
      }
      setDisplay(formattedResult);
      setEquation('');
    } catch (err) {
      setDisplay('ОШИБКА'); // Cyrillic for "ERROR"
      setEquation('');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 max-w-lg w-full" id="calc-view-container">
      {/* Retro Soviet branding title */}
      <div className="text-center mb-6" id="calc-title-box">
        <h1 className="text-3xl font-display font-bold tracking-widest text-soviet-red flex items-center justify-center gap-2 drop-shadow-[0_0_10px_rgba(230,57,70,0.5)]">
          <span>ЭЛЕКТРОНИКА</span> <Flame className="h-6 w-6 text-soviet-gold animate-pulse" />
        </h1>
        <p className="text-xs font-mono text-gray-500 mt-1 uppercase tracking-widest">
          МК-1987 • СДЕЛАНО В СССР
        </p>
      </div>

      {/* Main Container with 3D retro metal feel */}
      <div className="bg-zinc-900 border-4 border-zinc-800 p-6 rounded-2xl shadow-2xl relative overflow-hidden w-full max-w-sm" id="calc-body-frame">
        {/* Metal faceplate highlights */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-white/10 pointer-events-none" />

        {/* Vintage glowing Vacuum Fluorescent Display (VFD) */}
        <div 
          className={`bg-slate-950 border-2 border-zinc-700 p-4 rounded-lg mb-6 relative shadow-inner overflow-hidden transition-all duration-300 ${
            flashScreen ? 'bg-emerald-950/40 border-emerald-500/50' : ''
          }`}
          id="vfd-display"
        >
          {/* Subtle grid lines background overlay for scanlines effect */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%)] bg-[size:100%_4px] pointer-events-none" />
          
          <div className="flex justify-between items-center text-[10px] font-mono text-zinc-500 mb-1" id="vfd-status">
            <span className="tracking-widest">РЕЖИМ: АНАЛОГ</span>
            <span className="text-soviet-red animate-pulse flex items-center gap-1">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-soviet-red" /> СЕТЬ
            </span>
          </div>

          {/* Equation tracking line */}
          <div className="text-right h-4 text-xs font-mono text-emerald-600/70 select-none overflow-hidden" id="vfd-equation">
            {equation || <span className="opacity-0">0</span>}
          </div>

          {/* Main output numbers with green/cyan tube glow */}
          <div className="text-right text-3xl font-mono font-bold tracking-wider text-vfd-green drop-shadow-[0_0_8px_rgba(0,245,212,0.8)] h-10 select-all overflow-hidden" id="vfd-output">
            {display}
          </div>
        </div>

        {/* Calculator Grid */}
        <div className="grid grid-cols-4 gap-3" id="calc-pad-grid">
          {/* Row 1 */}
          <button
            id="btn-clear"
            onClick={handleClear}
            className="h-12 rounded bg-zinc-800 hover:bg-zinc-700 text-soviet-gold font-mono font-bold text-sm border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            СБР (C)
          </button>
          <button
            id="btn-back"
            onClick={handleBackspace}
            className="h-12 rounded bg-zinc-800 hover:bg-zinc-700 text-gray-300 font-mono font-bold text-sm border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            ←
          </button>
          <button
            id="btn-op-div"
            onClick={() => handleOperator('÷')}
            className="h-12 rounded bg-zinc-800 hover:bg-zinc-700 text-emerald-400 font-mono font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            ÷
          </button>
          <button
            id="btn-op-mul"
            onClick={() => handleOperator('×')}
            className="h-12 rounded bg-zinc-800 hover:bg-zinc-700 text-emerald-400 font-mono font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            ×
          </button>

          {/* Row 2 */}
          <button
            id="btn-num-7"
            onClick={() => handleNumber('7')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            7
          </button>
          <button
            id="btn-num-8"
            onClick={() => handleNumber('8')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            8
          </button>
          <button
            id="btn-num-9"
            onClick={() => handleNumber('9')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            9
          </button>
          <button
            id="btn-op-sub"
            onClick={() => handleOperator('-')}
            className="h-12 rounded bg-zinc-800 hover:bg-zinc-700 text-emerald-400 font-mono font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            -
          </button>

          {/* Row 3 */}
          <button
            id="btn-num-4"
            onClick={() => handleNumber('4')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            4
          </button>
          <button
            id="btn-num-5"
            onClick={() => handleNumber('5')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            5
          </button>
          <button
            id="btn-num-6"
            onClick={() => handleNumber('6')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            6
          </button>
          <button
            id="btn-op-add"
            onClick={() => handleOperator('+')}
            className="h-12 rounded bg-zinc-800 hover:bg-zinc-700 text-emerald-400 font-mono font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            +
          </button>

          {/* Row 4 */}
          <button
            id="btn-num-1"
            onClick={() => handleNumber('1')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            1
          </button>
          <button
            id="btn-num-2"
            onClick={() => handleNumber('2')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            2
          </button>
          <button
            id="btn-num-3"
            onClick={() => handleNumber('3')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            3
          </button>
          <button
            id="btn-op-eq"
            onClick={handleCalculate}
            className="h-28 rounded bg-soviet-red hover:bg-red-500 text-white font-mono font-bold text-xl border-b-4 border-red-950 row-span-2 flex items-center justify-center active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            =
          </button>

          {/* Row 5 */}
          <button
            id="btn-num-0"
            onClick={() => handleNumber('0')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-sans font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow col-span-2 cursor-pointer"
          >
            0
          </button>
          <button
            id="btn-dot"
            onClick={() => handleNumber('.')}
            className="h-12 rounded bg-zinc-700 hover:bg-zinc-650 text-white font-mono font-bold text-lg border-b-2 border-zinc-950 active:translate-y-0.5 transition-all shadow cursor-pointer"
          >
            .
          </button>
        </div>
      </div>

      {/* English Label at the very bottom */}
      <div className="mt-8 text-center" id="english-code-hint">
        <p className="text-sm font-mono text-zinc-500 hover:text-zinc-400 transition-colors tracking-widest uppercase">
          The code is 1987
        </p>
      </div>
    </div>
  );
}
